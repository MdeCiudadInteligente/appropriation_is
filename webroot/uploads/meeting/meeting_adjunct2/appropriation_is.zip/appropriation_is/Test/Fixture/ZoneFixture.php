<?php
/**
 * ZoneFixture
 *
 */
class ZoneFixture extends CakeTestFixture {

/**
 * Fields
 *
 * @var array
 */
	public $fields = array(
		'id_zone' => array('type' => 'integer', 'null' => false, 'default' => null, 'key' => 'primary'),
		'zone_name' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 45, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'indexes' => array(
			'PRIMARY' => array('column' => 'id_zone', 'unique' => 1)
		),
		'tableParameters' => array('charset' => 'latin1', 'collate' => 'latin1_swedish_ci', 'engine' => 'InnoDB')
	);

/**
 * Records
 *
 * @var array
 */
	public $records = array(
		array(
			'id_zone' => 1,
			'zone_name' => 'Lorem ipsum dolor sit amet'
		),
	);

}
