<?php
/**
 * SiteFixture
 *
 */
class SiteFixture extends CakeTestFixture {

/**
 * Fields
 *
 * @var array
 */
	public $fields = array(
		'id_site' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 45, 'key' => 'primary', 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'site_name' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 45, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'site_phone' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 45, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'site_address' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 45, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'site_mail' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 45, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'neighborhood_id' => array('type' => 'integer', 'null' => false, 'default' => null, 'key' => 'index'),
		'site_type_id' => array('type' => 'integer', 'null' => false, 'default' => null, 'key' => 'index'),
		'indexes' => array(
			'PRIMARY' => array('column' => 'id_site', 'unique' => 1),
			'neighborhood_id' => array('column' => array('neighborhood_id', 'site_type_id'), 'unique' => 0),
			'site_type_id' => array('column' => 'site_type_id', 'unique' => 0)
		),
		'tableParameters' => array('charset' => 'latin1', 'collate' => 'latin1_swedish_ci', 'engine' => 'InnoDB')
	);

/**
 * Records
 *
 * @var array
 */
	public $records = array(
		array(
			'id_site' => 'Lorem ipsum dolor sit amet',
			'site_name' => 'Lorem ipsum dolor sit amet',
			'site_phone' => 'Lorem ipsum dolor sit amet',
			'site_address' => 'Lorem ipsum dolor sit amet',
			'site_mail' => 'Lorem ipsum dolor sit amet',
			'neighborhood_id' => 1,
			'site_type_id' => 1
		),
	);

}
