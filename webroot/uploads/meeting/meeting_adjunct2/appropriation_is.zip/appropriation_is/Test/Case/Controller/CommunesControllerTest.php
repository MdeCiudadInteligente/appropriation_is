<?php
App::uses('CommunesController', 'Controller');

/**
 * CommunesController Test Case
 *
 */
class CommunesControllerTest extends ControllerTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.commune',
		'app.zone',
		'app.agent',
		'app.person',
		'app.owner',
		'app.site',
		'app.neighborhood',
		'app.site_type',
		'app.accompaniment',
		'app.meeting',
		'app.meeting_person',
		'app.user',
		'app.empleado',
		'app.diariocampo',
		'app.acompanamiento',
		'app.reunion'
	);

/**
 * testIndex method
 *
 * @return void
 */
	public function testIndex() {
	}

/**
 * testView method
 *
 * @return void
 */
	public function testView() {
	}

/**
 * testAdd method
 *
 * @return void
 */
	public function testAdd() {
	}

/**
 * testEdit method
 *
 * @return void
 */
	public function testEdit() {
	}

/**
 * testDelete method
 *
 * @return void
 */
	public function testDelete() {
	}

}
