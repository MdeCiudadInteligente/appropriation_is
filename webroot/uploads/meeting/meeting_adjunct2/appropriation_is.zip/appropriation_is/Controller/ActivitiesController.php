<?php
App::uses('AppController', 'Controller');
class ActivitiesController extends AppController {
	
	var $uses = array('Meeting','Accompaniment');
	public $components = array('Paginator');
   
   public function index(){
   	
   	$meeting=$this->Meeting->find('all');
   	
   	$this->set('meetings', $meeting);
   	
   	
   	
   	$this->Meeting->recursive = 0;
   	$this->set('meetings', $this->Paginator->paginate());
   	
   	
   	
   
   	
   	
   }
   
}
?>